package View;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Point;
import java.awt.Transparency;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.sound.midi.SysexMessage;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import exceptions.InvalidPowerUseException;
import exceptions.OccupiedCellException;
import exceptions.UnallowedMovementException;
import exceptions.WrongTurnException;
import model.game.Direction;
import model.game.Game;
import model.game.Player;
import model.pieces.Piece;
import model.pieces.heroes.ActivatablePowerHero;
import model.pieces.heroes.Armored;
import model.pieces.heroes.Medic;
import model.pieces.heroes.Ranged;
import model.pieces.heroes.Speedster;
import model.pieces.heroes.Super;
import model.pieces.heroes.Tech;
import model.pieces.sidekicks.SideKick;
import model.pieces.sidekicks.SideKickP1;
import model.pieces.sidekicks.SideKickP2;
import View.Welcome;

@SuppressWarnings("serial")
public class Gamewindow extends JFrame implements ActionListener {
	public JPanel panel;
	JLabel tele = new JLabel("Teleport");
	JLabel tar = new JLabel("Target");
	int rev;
	JTextField targetPiece1 = new JTextField("TT1");
	JTextField targetPiece2 = new JTextField("TT2");
	JTextField telePiece1 = new JTextField("TP1");
	JTextField telePiece2 = new JTextField("TP2");
	public JButton[][] buttons;
	public JButton[][] deadButtons1;
	public JButton[][] deadButtons2;
	public JButton label1;
	public JButton label2;
	public JPanel dead1;
	public JPanel dead2;
	public JPanel Arrow;
	public JPanel powerArrow;
	public JButton[][] Arrows;
	public JButton[][] powerArrows;
	//public JButton play;
	// public JButton play1;
	// private ImageIcon image;
	public static int posI;
	public static int posJ;
	public Direction powerDir;
	public Direction moveDir;
	Game game;
	Piece piece;
	public JProgressBar payload1 = new JProgressBar();
	public JProgressBar payload2 = new JProgressBar();
	Welcome w;

	public Gamewindow(Game g) {
		this.game = g;
		this.getContentPane().setLayout(null);

		try {
			this.setContentPane(new JLabel(new ImageIcon(ImageIO.read(new File(
					"0348161d164fd0fb2b447e7e5f864ad6.jpg")))));
		} catch (IOException e)

		{
			System.out.println("image");
		}
		payload1.setMinimum(0);
		payload1.setValue(0);
		payload1.setMaximum(6);
		payload2.setMinimum(0);
		payload2.setValue(0);
		payload2.setMaximum(6);
		payload1.setForeground(Color.magenta.darker().darker());
		payload2.setForeground(Color.magenta.darker().darker());
		this.setResizable(false);
		panel = new JPanel();
		panel.setLayout(new GridLayout(7, 6));
		panel.setBounds(546, 195, 542, 515);
		panel.setBackground(Color.WHITE);
		targetPiece1.setBounds(95, 100, 50, 30);
		targetPiece2.setBounds(150, 100, 50, 30);
		telePiece1.setBounds(95, 175, 50, 30);
		telePiece2.setBounds(150, 175, 50, 30);
		JLabel target=new JLabel();
		JLabel teleport=new JLabel();
		target.setText("Target");
		teleport.setText("Teleport");
		target.setBounds(130, 70, 50, 30);
		teleport.setBounds(120, 145, 50, 30);
		target.setForeground(Color.white);
		teleport.setForeground(Color.white);
		this.add(target);
		this.add(teleport);

		this.add(targetPiece1);
		this.add(targetPiece2);
		this.add(telePiece1);
		this.add(telePiece2);
		this.add(panel);
		this.getContentPane().add(panel);
		buttons = new JButton[7][6];
		for (int i = 0; i < 7; i++) {
			for (int j = 0; j < 6; j++) {
				buttons[i][j] = new JButton();
				panel.add(buttons[i][j]);
				// buttons[i][j].setBackground(Color.red);
			}
		}
		payload1.setBounds(400, 195, 40, 250);
		payload2.setBounds(400, 458, 40, 250);
		this.getContentPane().add(payload1);
		this.getContentPane().add(payload2);
		for (int i = 0; i < 7; i++) {
			if (i % 2 == 0) {
				for (int j = 0; j < 6; j = j + 2) {
					buttons[i][j]
							.setBackground(Color.magenta.darker().darker());
					buttons[i][j + 1].setBackground(Color.white);
				}
			} else
				for (int j = 0; j < 6; j = j + 2) {
					buttons[i][j].setBackground(Color.white);
					buttons[i][j + 1].setBackground(Color.magenta.darker()
							.darker());
				}

		}
		// label1=new JLabel("player1");
		// label1.setBounds(800,600, 50, 50);
		// label1.setBackground(Color.red);
		// label1.setForeground(Color.BLACK);
		// label1.setBackground(Color.red);
		// add(label1);
		// this.getContentPane().add(label1, BorderLayout.SOUTH);

		dead1 = new JPanel();
		dead1.setLayout(new GridLayout(9, 1));
		dead1.setBounds(1090, 70, 90, 661);
		dead1.setOpaque(false);

		/*
		 * try { image = new ImageIcon( ImageIO.read(new File(
		 * "depositphotos_87453442-stock-photo-gold-background-vertical.jpg")));
		 * } catch (IOException ex) { System.out.println("image"); }
		 */

		// dead1.setBackground(Color.WHITE);

		this.getContentPane().add(dead1);

		dead2 = new JPanel();
		dead2.setLayout(new GridLayout(9, 1));
		dead2.setBounds(453, 70, 90, 661);

		dead2.setOpaque(false);

		this.getContentPane().add(dead2);

		Arrow = new JPanel();
		Arrow.setLayout(new GridLayout(3, 3));
		Arrow.setBackground(Color.WHITE);
		Arrow.setBounds(95, 480, 150, 150);
		this.add(Arrow);
		this.getContentPane().add(Arrow);
		Arrows = new JButton[3][3];
		Arrows[0][0] = new JButton(new ImageIcon("arrow_up_left.png"));
		// mage up = new ImageIcon(this.getClass())
		// Arrows[0][0].setIcon(new ImageIcon("up.png"));
		// Arrows[0][0].setBackground(Color.blue);
		Arrow.add(Arrows[0][0]);
		Arrows[1][0] = new JButton(new ImageIcon("images.png"));
		// Arrows[1][0].setBackground(Color.red);
		Arrow.add(Arrows[1][0]);
		Arrows[2][0] = new JButton(new ImageIcon("arrow_up_right.png"));
		Arrows[2][0].setBackground(Color.blue);
		Arrow.add(Arrows[2][0]);
		Arrows[0][1] = new JButton(new ImageIcon("left.jpg"));
		Arrows[0][1].setBackground(Color.red);
		Arrow.add(Arrows[0][1]);
		Arrows[1][1] = new JButton();
		Arrows[1][1].setBackground(Color.BLACK);
		Arrows[1][1].setForeground(Color.WHITE);
		Arrows[1][1].setText("M");
		Arrows[1][1].setFont(new Font("Courier", Font.BOLD, 25));
		Arrow.add(Arrows[1][1]);
		Arrows[2][1] = new JButton(new ImageIcon("right.jpg"));
		Arrows[2][1].setBackground(Color.red);
		Arrow.add(Arrows[2][1]);
		Arrows[0][2] = new JButton(new ImageIcon("arrow_down_left.png"));
		Arrows[0][2].setBackground(Color.blue);
		Arrow.add(Arrows[0][2]);
		Arrows[1][2] = new JButton(new ImageIcon("down.jpg"));
		Arrows[1][2].setBackground(Color.red);
		Arrow.add(Arrows[1][2]);
		Arrows[2][2] = new JButton(new ImageIcon("arrow_down_right.png"));
		Arrows[2][2].setBackground(Color.blue);
		Arrow.add(Arrows[2][2]);
		powerArrow = new JPanel();
		powerArrow.setLayout(new GridLayout(3, 3));
		powerArrow.setBackground(Color.WHITE);
		powerArrow.setBounds(95, 250, 150, 150);
		this.add(powerArrow);
		this.getContentPane().add(powerArrow);
		powerArrows = new JButton[3][3];
		powerArrows[0][0] = new JButton(new ImageIcon("arrow_up_left.png"));
		// mage up = new ImageIcon(this.getClass())
		// Arrows[0][0].setIcon(new ImageIcon("up.png"));
		// Arrows[0][0].setBackground(Color.blue);
		powerArrow.add(powerArrows[0][0]);
		powerArrows[1][0] = new JButton(new ImageIcon("images.png"));
		// Arrows[1][0].setBackground(Color.red);
		powerArrow.add(powerArrows[1][0]);
		powerArrows[2][0] = new JButton(new ImageIcon("arrow_up_right.png"));
		powerArrows[2][0].setBackground(Color.blue);
		powerArrow.add(powerArrows[2][0]);
		powerArrows[0][1] = new JButton(new ImageIcon("left.jpg"));
		powerArrows[0][1].setBackground(Color.red);
		powerArrow.add(powerArrows[0][1]);
		powerArrows[1][1] = new JButton();
		powerArrows[1][1].setBackground(Color.BLACK);
		powerArrows[1][1].setForeground(Color.WHITE);
		powerArrows[1][1].setText("P");
		powerArrows[1][1].setFont(new Font("Courier", Font.BOLD, 25));
		powerArrow.add(powerArrows[1][1]);
		powerArrows[2][1] = new JButton(new ImageIcon("right.jpg"));
		powerArrows[2][1].setBackground(Color.red);
		powerArrow.add(powerArrows[2][1]);
		powerArrows[0][2] = new JButton(new ImageIcon("arrow_down_left.png"));
		powerArrows[0][2].setBackground(Color.blue);
		powerArrow.add(powerArrows[0][2]);
		powerArrows[1][2] = new JButton(new ImageIcon("down.jpg"));
		powerArrows[1][2].setBackground(Color.red);
		powerArrow.add(powerArrows[1][2]);
		powerArrows[2][2] = new JButton(new ImageIcon("arrow_down_right.png"));
		powerArrows[2][2].setBackground(Color.blue);
		powerArrow.add(powerArrows[2][2]);
		deadButtons1 = new JButton[9][1];
		deadButtons2 = new JButton[9][1];
		deadButtons1[0][0] = new JButton();
		dead1.add(deadButtons1[0][0]);
		deadButtons1[1][0] = new JButton();
		dead1.add(deadButtons1[1][0]);
		deadButtons1[2][0] = new JButton();
		dead1.add(deadButtons1[2][0]);
		deadButtons1[3][0] = new JButton();
		dead1.add(deadButtons1[3][0]);
		deadButtons1[4][0] = new JButton();
		dead1.add(deadButtons1[4][0]);
		deadButtons1[5][0] = new JButton();
		dead1.add(deadButtons1[5][0]);
		deadButtons1[6][0] = new JButton();
		dead1.add(deadButtons1[6][0]);
		deadButtons1[7][0] = new JButton();
		dead1.add(deadButtons1[7][0]);
		deadButtons1[8][0] = new JButton();
		dead1.add(deadButtons1[8][0]);
		deadButtons2[0][0] = new JButton();
		dead2.add(deadButtons2[0][0]);
		deadButtons2[1][0] = new JButton();
		dead2.add(deadButtons2[1][0]);
		deadButtons2[2][0] = new JButton();
		dead2.add(deadButtons2[2][0]);
		deadButtons2[3][0] = new JButton();
		dead2.add(deadButtons2[3][0]);
		deadButtons2[4][0] = new JButton();
		dead2.add(deadButtons2[4][0]);
		deadButtons2[5][0] = new JButton();
		dead2.add(deadButtons2[5][0]);
		deadButtons2[6][0] = new JButton();
		dead2.add(deadButtons2[6][0]);
		deadButtons2[7][0] = new JButton();
		dead2.add(deadButtons2[7][0]);
		deadButtons2[8][0] = new JButton();
		dead2.add(deadButtons2[8][0]);
		for (int i = 0; i < 9; i++) {
			deadButtons1[i][0].setContentAreaFilled(false);
			deadButtons1[i][0].setBorderPainted(false);
			deadButtons1[i][0].addActionListener(this);
			deadButtons2[i][0].setContentAreaFilled(false);
			deadButtons2[i][0].setBorderPainted(false);
			deadButtons2[i][0].addActionListener(this);

		}

		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				Arrows[i][j].addActionListener(this);
				powerArrows[i][j].addActionListener(this);
			}
		}
		for (int i = 0; i < 7; i++) {
			for (int j = 0; j < 6; j++) {
				buttons[i][j].addActionListener(this);
			}
		}
		for (int i = 0; i < 9; i++) {
			deadButtons1[i][0].addActionListener(this);
			deadButtons2[i][0].addActionListener(this);
		}
		label1 = new JButton();
		label1.setText(game.getPlayer1().getName()+"'s Turn");
		label1.setBounds(680, 100, 250, 50);
		label1.setBackground(Color.magenta.darker().darker());
		label1.setForeground(Color.white);
		// label1.setBackground(Color.red);

		this.getContentPane().add(label1);

		label2 = new JButton();
		label2.setText(game.getPlayer2().getName()+"'s Turn");
		label2.setBounds(680, 110, 250, 50);
		label2.setBackground(Color.white);
		label2.setForeground(Color.magenta.darker().darker());
		// label1.setBackground(Color.red);
		label2.setVisible(false);
		this.getContentPane().add(label2);

		/*play = new JButton("PLAY");
		play.setBounds(980, 730, 70, 70);
		play.setBackground(Color.GREEN);
		play.setForeground(Color.BLACK);
		// play.addActionListener(this);
		add(play);
		this.getContentPane().add(play);*/

		this.setSize(1500, 1000);
		this.setBackground(Color.BLACK);
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		setBoard();
		updateDead();
	}

	public void setBoard() {
		for (int i = 0; i < 7; i++) {
			for (int j = 0; j < 6; j++) {
				if (game.getCellAt(i, j).getPiece() == null) {
					buttons[i][j].setIcon(null);
					buttons[i][j].setToolTipText("Empty Cell");
				} else {
					Piece piece = game.getCellAt(i, j).getPiece();
					if (piece instanceof Super) {
						if (piece.getOwner() == game.getPlayer1()) {
							buttons[i][j].setIcon(new ImageIcon(
									"rsz_kakashi.png"));
							buttons[i][j].setToolTipText(game.getPlayer1().getName()
									+ "'s Super"
									+ ", Power used: "
									+ ((ActivatablePowerHero) piece)
											.isPowerUsed());
						} else {
							buttons[i][j].setIcon(new ImageIcon(
									"rsz_obitoo.png"));
							buttons[i][j].setToolTipText(game.getPlayer2().getName()
									+ "'s Super"
									+ ", Power used: "
									+ ((ActivatablePowerHero) piece)
											.isPowerUsed());
						}

					}
					if (piece instanceof Ranged) {
						if (piece.getOwner() == game.getPlayer1()) {
							buttons[i][j].setIcon(new ImageIcon(
									"rsz_narutoo.png"));
							buttons[i][j].setToolTipText(game.getPlayer1().getName()
									+ "'s Ranged"
									+ ", Power used: "
									+ ((ActivatablePowerHero) piece)
											.isPowerUsed());
						} else {
							buttons[i][j].setIcon(new ImageIcon(
									"rsz_madara.png"));
							buttons[i][j].setToolTipText(game.getPlayer2().getName()
									+ "'s Ranged"
									+ ", Power used: "
									+ ((ActivatablePowerHero) piece)
											.isPowerUsed());
						}

					}
					if (piece instanceof Tech) {
						if (piece.getOwner() == game.getPlayer1()) {
							buttons[i][j].setIcon(new ImageIcon(
									"rsz_minato.png"));
							buttons[i][j].setToolTipText(game.getPlayer1().getName()
									+ "'s Tech"
									+ ", Power used: "
									+ ((ActivatablePowerHero) piece)
											.isPowerUsed());
						} else {
							buttons[i][j].setIcon(new ImageIcon(
									"rsz_kabuto.png"));
							buttons[i][j].setToolTipText(game.getPlayer2().getName()
									+ "'s Tech"
									+ ", Power used: "
									+ ((ActivatablePowerHero) piece)
											.isPowerUsed());
						}

					}
					if (piece instanceof Medic) {
						if (piece.getOwner() == game.getPlayer1()) {
							buttons[i][j].setIcon(new ImageIcon(
									"rsz_sakura.png"));
							buttons[i][j].setToolTipText(game.getPlayer1().getName()
									+ "'s Medic"
									+ ", Power used: "
									+ ((ActivatablePowerHero) piece)
											.isPowerUsed());
						} else {
							buttons[i][j].setIcon(new ImageIcon(
									"rsz_1hidan.png"));
							buttons[i][j].setToolTipText(game.getPlayer2().getName()
									+ "'s Medic"
									+ ", Power used: "
									+ ((ActivatablePowerHero) piece)
											.isPowerUsed());
						}

					}
					if (piece instanceof Armored) {
						if (piece.getOwner() == game.getPlayer1()) {
							buttons[i][j].setIcon(new ImageIcon(
									"rsz_gaara_by_reizdrawing-db3lb4w.png"));
							buttons[i][j].setToolTipText(game.getPlayer1().getName()
									+ "'s Armored" + ", ArmorUp: "
									+ ((Armored) piece).isArmorUp());
						} else {
							buttons[i][j].setIcon(new ImageIcon(
									"rsz_sasori.png"));
							buttons[i][j].setToolTipText(game.getPlayer2().getName()
									+ "'s Armored" + ", ArmorUp: "
									+ ((Armored) piece).isArmorUp());
						}

					}
					if (piece instanceof Speedster) {
						if (piece.getOwner() == game.getPlayer1()) {
							buttons[i][j].setIcon(new ImageIcon(
									"rsz_sasukee.png"));
							buttons[i][j].setToolTipText(game.getPlayer1().getName()
									+ "'s Speedster");
						} else {
							buttons[i][j]
									.setIcon(new ImageIcon(
											"rsz_itachi-uchiha-itachi-uchiha-1306062-800-600.png"));
							buttons[i][j].setToolTipText(game.getPlayer2().getName()
									+ "'s Speedster");
						}

					}
					if (piece instanceof SideKickP1) {

						buttons[i][j].setIcon(new ImageIcon(
								"rsz_uchiha_anbu.png"));
						buttons[i][j].setToolTipText(game.getPlayer1().getName()
								+ "'s SideKick Player1");
					}
					if (piece instanceof SideKickP2) {
						buttons[i][j].setIcon(new ImageIcon(
								"rsz_zetsu_sigma.png"));
						buttons[i][j].setToolTipText(game.getPlayer2().getName()
								+ "'s SideKick Player2");
					}
				}
			}
		}
		updateDead();
	}

	public void actionPerformed(ActionEvent e) {
		for (int i = 0; i < 7; i++) {
			for (int j = 0; j < 6; j++) {
				if (e.getSource() == buttons[i][j]) {
					posI = i;
					posJ = j;

				}

			}
		}
		if (e.getSource() == Arrows[0][0]) {
			moveDir = (Direction.UPLEFT);
		}
		if (e.getSource() == Arrows[1][0]) {
			moveDir = (Direction.UP);
		}
		if (e.getSource() == Arrows[2][0]) {
			moveDir = (Direction.UPRIGHT);
		}
		if (e.getSource() == Arrows[0][1]) {
			moveDir = (Direction.LEFT);
		}
		if (e.getSource() == Arrows[2][1]) {
			moveDir = (Direction.RIGHT);
		}
		if (e.getSource() == Arrows[0][2]) {
			moveDir = (Direction.DOWNLEFT);
		}
		if (e.getSource() == Arrows[1][2]) {
			moveDir = (Direction.DOWN);
		}
		if (e.getSource() == Arrows[2][2]) {
			moveDir = (Direction.DOWNRIGHT);
		}
		if (e.getSource() == Arrows[1][1]) {
			move(moveDir);
		}

		if (e.getSource() == powerArrows[0][0]) {
			powerDir = Direction.UPLEFT;
		}
		if (e.getSource() == powerArrows[1][0]) {
			powerDir = (Direction.UP);
		}
		if (e.getSource() == powerArrows[2][0]) {
			powerDir = (Direction.UPRIGHT);
		}
		if (e.getSource() == powerArrows[0][1]) {
			powerDir = (Direction.LEFT);
		}
		if (e.getSource() == powerArrows[2][1]) {
			powerDir = (Direction.RIGHT);
		}
		if (e.getSource() == powerArrows[0][2]) {
			powerDir = (Direction.DOWNLEFT);
		}
		if (e.getSource() == powerArrows[1][2]) {
			powerDir = (Direction.DOWN);
		}
		if (e.getSource() == powerArrows[2][2]) {
			powerDir = (Direction.DOWNRIGHT);
		}
		if (e.getSource() == powerArrows[1][1]) {
			power(powerDir);
		}
		for (int i = 0; i < 9; i++) {
			if (e.getSource() == deadButtons2[i][0]) {
				rev = i;
			}
			if (e.getSource() == deadButtons1[i][0]) {
				rev = i;
			}
		}
	}

	public void updateDead() {
		for (int i = 0; i < 9; i++) {
			deadButtons1[i][0].setIcon(null);
			deadButtons2[i][0].setIcon(null);
		}
		for (int i = 0; i < game.getPlayer1().getDeadCharacters().size(); i++) {

			if (!game.getPlayer1().getDeadCharacters().isEmpty()) {
				piece = game.getPlayer1().getDeadCharacters().get(i);
				if (piece instanceof Super) {
					deadButtons1[i][0]
							.setIcon(new ImageIcon("rsz_kakashi.png"));
					deadButtons1[i][0].setToolTipText(game.getPlayer1()
							+ "'s Super" + ", Power used: "
							+ ((ActivatablePowerHero) piece).isPowerUsed());
				}
				if (piece instanceof Ranged) {
					deadButtons1[i][0]
							.setIcon(new ImageIcon("rsz_narutoo.png"));
					deadButtons1[i][0].setToolTipText(game.getPlayer1()
							+ "'s Ranged" + ", Power used: "
							+ ((ActivatablePowerHero) piece).isPowerUsed());
				}
				if (piece instanceof Tech) {
					deadButtons1[i][0].setIcon(new ImageIcon("rsz_minato.png"));
					deadButtons1[i][0].setToolTipText(game.getPlayer1()
							+ "'s Tech" + ", Power used: "
							+ ((ActivatablePowerHero) piece).isPowerUsed());
				}
				if (piece instanceof Medic) {
					deadButtons1[i][0].setIcon(new ImageIcon("rsz_sakura.png"));
					deadButtons1[i][0].setToolTipText(game.getPlayer1()
							+ "'s Medic" + ", Power used: "
							+ ((ActivatablePowerHero) piece).isPowerUsed());
				}
				if (piece instanceof Armored) {
					deadButtons1[i][0].setIcon(new ImageIcon(
							"rsz_gaara_by_reizdrawing-db3lb4w.png"));
					deadButtons1[i][0].setToolTipText(game.getPlayer1()
							+ "'s Armored" + ", ArmorUp: "
							+ ((Armored) piece).isArmorUp());
				}
				if (piece instanceof Speedster) {
					deadButtons1[i][0]
							.setIcon(new ImageIcon("rsz_sasukee.png"));
					deadButtons1[i][0].setToolTipText(game.getPlayer1()
							+ "'s Speedster");
				}
				if (piece instanceof SideKickP1) {

					deadButtons1[i][0].setIcon(new ImageIcon(
							"rsz_uchiha_anbu.png"));
					deadButtons1[i][0].setToolTipText(game.getPlayer1()
							+ "'s SideKick Player1");
				}

			}
			if (!game.getPlayer2().getDeadCharacters().isEmpty()) {
				piece = game.getPlayer2().getDeadCharacters().get(i);
				if (piece instanceof Super) {
					deadButtons2[i][0].setIcon(new ImageIcon("rsz_obitoo.png"));
					deadButtons2[i][0].setToolTipText(game.getPlayer2()
							+ "'s Super" + ", Power used: "
							+ ((ActivatablePowerHero) piece).isPowerUsed());
				}
				if (piece instanceof Ranged) {
					deadButtons2[i][0].setIcon(new ImageIcon("rsz_madara.png"));
					deadButtons2[i][0].setToolTipText(game.getPlayer2()
							+ "'s Ranged" + ", Power used: "
							+ ((ActivatablePowerHero) piece).isPowerUsed());
				}
				if (piece instanceof Tech) {
					deadButtons2[i][0].setIcon(new ImageIcon("rsz_kabuto.png"));
					deadButtons2[i][0].setToolTipText(game.getPlayer2()
							+ "'s Tech" + ", Power used: "
							+ ((ActivatablePowerHero) piece).isPowerUsed());
				}
				if (piece instanceof Medic) {
					deadButtons2[i][0].setIcon(new ImageIcon("rsz_1hidan.png"));
					deadButtons2[i][0].setToolTipText(game.getPlayer2()
							+ "'s Medic" + ", Power used: "
							+ ((ActivatablePowerHero) piece).isPowerUsed());
				}
				if (piece instanceof Armored) {
					deadButtons2[i][0].setIcon(new ImageIcon("rsz_sasori.png"));
					deadButtons2[i][0].setToolTipText(game.getPlayer2()
							+ "'s Armored" + ", ArmorUp: "
							+ ((Armored) piece).isArmorUp());
				}
				if (piece instanceof Speedster) {
					deadButtons2[i][0]
							.setIcon(new ImageIcon(
									"rsz_itachi-uchiha-itachi-uchiha-1306062-800-600.png"));
					deadButtons2[i][0].setToolTipText(game.getPlayer2()
							+ "'s Speedster");
				}
				if (piece instanceof SideKickP2) {

					deadButtons2[i][0].setIcon(new ImageIcon(
							"rsz_zetsu_sigma.png"));
					deadButtons2[i][0].setToolTipText(game.getPlayer1()
							+ "'s SideKick Player2");
				}

			}
			payload1.setOrientation(SwingConstants.VERTICAL);
			payload2.setOrientation(SwingConstants.VERTICAL);
			payload1.setValue(game.getPlayer1().getPayloadPos());
			payload2.setValue(game.getPlayer2().getPayloadPos());
		}
	}

	public void power(Direction r) {
		Piece p = game.getCellAt(posI, posJ).getPiece();
		Piece target = null;
		Point p1 = null;
		if (p == null) {
			JOptionPane.showMessageDialog(null, "You are using an empty cell");
			return;
		}
		if (p instanceof SideKick) {
			JOptionPane.showMessageDialog(null,
					"Sidekick as no power");
			return;
		}
		if (p instanceof Armored) {
			JOptionPane.showMessageDialog(null,
					"Armored has no power");
			return;
		}
		if (p instanceof Speedster) {
			JOptionPane.showMessageDialog(null,
					"Speedster has no power");
			return;
		} else {
			try {
				if (p instanceof Medic) {
					try {
						target = game.getCurrentPlayer().getDeadCharacters()
								.get(rev);
					} catch (Exception e) {
						JOptionPane.showMessageDialog(null,
								"You are reviving an enemy piece");
					}
				}
				if (p instanceof Tech) {
					try {
						target = game.getCellAt(
								Integer.parseInt(targetPiece1.getText()),
								Integer.parseInt(targetPiece2.getText()))
								.getPiece();
					} catch (Exception e) {
						target = null;
					}
					try {
						p1 = new Point(Integer.parseInt(telePiece1.getText()),
								Integer.parseInt(telePiece2.getText()));
					} catch (Exception e) {
						p1 = null;
					}

				}
				((ActivatablePowerHero) p).usePower(r, target, p1);
				setBoard();
				updateDead();
			} catch (InvalidPowerUseException | WrongTurnException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void move(Direction r) {

		if (game.getCellAt(posI, posJ).getPiece() == null) {
			JOptionPane.showMessageDialog(null, "Press a Piece");
		} else
			try {
				game.getCellAt(posI, posJ).getPiece().move(r);
				if (label1.isVisible()) {
					label1.setVisible(false);
					label2.setVisible(true);
				} else {
					label1.setVisible(true);
					label2.setVisible(false);
				}
				this.setBoard();
				updateDead();

			} catch (UnallowedMovementException | OccupiedCellException
					| WrongTurnException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	public static void main(String[] args)
	{
		// playername player = new playername();
		// Gamewindow g = new Gamewindow(player);

	}

}
