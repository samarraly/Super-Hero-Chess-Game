package View;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;

import model.game.Game;
import model.game.Player;
import model.pieces.Piece;
import model.pieces.heroes.*;
import model.pieces.sidekicks.SideKickP1;
import model.pieces.sidekicks.SideKickP2;

public class Welcome extends JFrame implements ActionListener {
	JTextField tf1;
	JButton start;
	JLabel l1;
	JLabel l2;
	JLabel welcome;
	JLabel player1;
	JLabel player2;
	JTextField tf2;
	


		public Welcome() {

		tf1 = new JTextField();
		setResizable(false);
		setVisible(true);
		setLayout(null);
		try {
			this.setContentPane(new JLabel(new ImageIcon(ImageIO.read(new File(
					"naruto vs sasuke 1.jpg")))));
		} catch (IOException e)

		{
			System.out.println("image");
		}
		getContentPane().setBackground(Color.BLACK);
		tf2 = new JTextField();
		start = new JButton();
		l1 = new JLabel();
		l2 = new JLabel();
		welcome = new JLabel();
		setBounds(200, 0, 900, 900);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		tf1.setBounds(260, 360, 160, 20);
		getContentPane().add(tf1);
		tf2.setBounds(450, 360, 160, 20);
		getContentPane().add(tf2);
		welcome.setText("Welcome to Anime Heroes Chess Board");
		welcome.setBounds(190, 160, 600, 300);
		getContentPane().add(welcome);
		welcome.setForeground(Color.BLACK);
		welcome.setFont(new Font("Courier", Font.BOLD, 25));
		player1 = new JLabel();
		player1.setText("Player 1 Name");
		player1.setBounds(260, 330, 100, 30);
		getContentPane().add(player1);
		player1.setForeground(Color.WHITE);
		player2 = new JLabel();
		player2.setText("Player 2 Name");
		player2.setBounds(450, 330, 100, 30);
		getContentPane().add(player2);
		player2.setForeground(Color.BLACK);
		start = new JButton();
		start.setBounds(380, 420, 100, 30);
		start.setText("Start");
		getContentPane().add(start);
		start.addActionListener((ActionListener) this);
		
	}

	public static void main(String[] args)
	{
		Welcome f = new Welcome();
		

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == start)
		{
			this.setVisible(false);
			//String p1name = tf1.getText();
			//String p2name = tf2.getText();
			Player p1 = new Player(tf1.getText()+"");
			Player p2 = new Player(tf2.getText()+"");
			Game g = new Game(p1, p2);
			Gamewindow gw = new Gamewindow(g);
			
			
		}

	}
	

}
